// UIInventoryView.cs�i�����ւ�/�g���j
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIInventoryView : MonoBehaviour
{
    [SerializeField] GameObject root;
    [SerializeField] RectTransform bagGrid;        // �� UIItemCountEntry ����ׂ�
    [SerializeField] RectTransform relicGrid;      // �� ����
    [SerializeField] UIItemCountEntry itemCountPrefab;  // �� �V�v���n�u

    [Header("Consumables")]
    [SerializeField] RectTransform consumableGrid;
    [SerializeField] UIConsumableEntry consumablePrefab;
    [SerializeField] ConsumableCatalogSO consumableCatalog;   // �� �ǉ��F�J�^���O
    // �\�����̊e�G���g����ێ��i��ŃJ�E���g�X�V���₷���j
    Dictionary<ConsumableType, UIConsumableEntry> consumableEntries = new();

    [SerializeField] Button closeButton;

    bool removeMode = false;
    Action<SymbolSO> onRemoveSymbol;
    Action<RelicSO> onRemoveRelic;

    // �����L���b�V���i�\�����J�E���g�j
    Dictionary<SymbolSO, int> bagCounts = new();
    Dictionary<RelicSO, int> relicCounts = new();
    // �\�����G���g���ւ̋t����
    Dictionary<SymbolSO, UIItemCountEntry> bagEntries = new();
    Dictionary<RelicSO, UIItemCountEntry> relicEntries = new();

    void Awake()
    {
        root.SetActive(false);
        closeButton.onClick.AddListener(() => Close());
    }

    public void Open(
        RunState run,
        bool removeMode,
        Action<SymbolSO> onRemoveSymbol,
        Action<RelicSO> onRemoveRelic,
        Action<ConsumableType> onClickConsumable = null
    )
    {
        this.removeMode = removeMode;
        this.onRemoveSymbol = onRemoveSymbol;
        this.onRemoveRelic = onRemoveRelic;

        root.SetActive(true);

        RebuildBagGrouped(run.Bag);
        RebuildRelicsGrouped(run.Relics);
        RebuildConsumables(run.Consumables, onClickConsumable);
    }

    public void Close() => root.SetActive(false);

    void ClearChildren(Transform t) { for (int i = t.childCount - 1; i >= 0; i--) Destroy(t.GetChild(i).gameObject); }

    // ===== Bag�i�V���{���j =====
    void RebuildBagGrouped(Bag bag)
    {
        bagCounts.Clear(); bagEntries.Clear(); ClearChildren(bagGrid);
        if (bag?.Items == null) return;

        foreach (var s in bag.Items)
        {
            if (s == null) continue;
            bagCounts.TryGetValue(s, out int c); bagCounts[s] = c + 1;
        }

        foreach (var kv in bagCounts)
        {
            var entry = Instantiate(itemCountPrefab, bagGrid);
            entry.Bind(
                kv.Key.Icon,
                kv.Key.Id,
                kv.Value,
                payload: kv.Key,
                onClick: (obj) => {
                    if (!removeMode) return;
                    var sym = obj as SymbolSO;
                    if (sym == null) return;
                    onRemoveSymbol?.Invoke(sym);  // GameController���� Bag ����1�� Remove ����
                },
                interactable: removeMode // �������[�h�̂Ƃ�����������
            );
            bagEntries[kv.Key] = entry;
        }
    }

    // Bag UI�́g1���������炷�h���f�iGameController����Ăׂ郆�[�e�B���e�B�j
    public void OnBagOneRemoved(SymbolSO sym)
    {
        if (sym == null) return;
        if (!bagCounts.TryGetValue(sym, out var c)) return;
        c -= 1;
        if (c <= 0)
        {
            bagCounts.Remove(sym);
            if (bagEntries.TryGetValue(sym, out var e))
            {
                Destroy(e.gameObject);
                bagEntries.Remove(sym);
            }
        }
        else
        {
            bagCounts[sym] = c;
            if (bagEntries.TryGetValue(sym, out var e)) e.SetCount(c);
        }
    }

    // ===== Relics =====
    void RebuildRelicsGrouped(List<RelicSO> relics)
    {
        relicCounts.Clear(); relicEntries.Clear(); ClearChildren(relicGrid);
        if (relics == null) return;

        foreach (var r in relics)
        {
            if (r == null) continue;
            relicCounts.TryGetValue(r, out int c); relicCounts[r] = c + 1;
        }

        foreach (var kv in relicCounts)
        {
            var entry = Instantiate(itemCountPrefab, relicGrid);
            entry.Bind(
                kv.Key.Icon,
                kv.Key.Id,
                kv.Value,
                payload: kv.Key,
                onClick: (obj) => {
                    if (!removeMode) return;
                    var rel = obj as RelicSO;
                    if (rel == null) return;
                    onRemoveRelic?.Invoke(rel);   // GameController���� Relics ����1�� Remove
                },
                interactable: removeMode
            );
            relicEntries[kv.Key] = entry;
        }
    }

    public void OnRelicOneRemoved(RelicSO relic)
    {
        if (relic == null) return;
        if (!relicCounts.TryGetValue(relic, out var c)) return;
        c -= 1;
        if (c <= 0)
        {
            relicCounts.Remove(relic);
            if (relicEntries.TryGetValue(relic, out var e))
            {
                Destroy(e.gameObject);
                relicEntries.Remove(relic);
            }
        }
        else
        {
            relicCounts[relic] = c;
            if (relicEntries.TryGetValue(relic, out var e)) e.SetCount(c);
        }
    }

    // ===== Consumables �͏]���ʂ� =====
    void RebuildConsumables(ConsumableCounts c, Action<ConsumableType> onClick)
    {
        ClearChildren(consumableGrid);
        consumableEntries.Clear();
        if (consumableCatalog == null) return;

        void add(ConsumableType t, int count)
        {
            var so = consumableCatalog.Get(t);
            if (so == null) return; // �J�^���O���ݒ�
            var e = Instantiate(consumablePrefab, consumableGrid);
            e.Bind(so, count, (clickedSO) => onClick?.Invoke(clickedSO.Type));
            consumableEntries[t] = e;
        }

        add(ConsumableType.RemoveToken, c.RemoveToken);
        add(ConsumableType.RerollItem, c.RerollItem);
        add(ConsumableType.RerollRelic, c.RerollRelic);
    }

    // �g�������Ƃ�UI�����X�V�������ꍇ�̃w���p
    public void SetConsumableCount(ConsumableType t, int count)
    {
        if (consumableEntries.TryGetValue(t, out var e)) e.SetCount(count);
    }
}
