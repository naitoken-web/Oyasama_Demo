using UnityEngine;

[CreateAssetMenu(fileName = "Spin", menuName = "Scriptable Objects/SpinSystem")]
public class SpinSystem : ScriptableObject
{
    public int Width = 5, Height = 4;
    public SymbolSO[,] Spin(Bag bag, System.Random rng)
    {
        var grid = new SymbolSO[Width, Height];
        for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width; x++)
                grid[x, y] = bag.WeightedPick(rng);
        return grid;
    }
}