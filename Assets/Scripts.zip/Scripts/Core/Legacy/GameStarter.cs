// GameStarter.cs
using UnityEngine;
public class GameStarter : MonoBehaviour
{
    [SerializeField] BoardView boardView;
    [SerializeField] Sprite[] dummySprites; // ���ł�OK�i���A�C�R���j
    void Start()
    {
        //boardView.FillDummy(dummySprites);
    }
}
