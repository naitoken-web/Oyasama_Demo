// Bag.cs�i�ŏ��j
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(menuName = "Lucklike/Bag")]
public class Bag : ScriptableObject
{
    public List<SymbolSO> Items = new();
    public SymbolSO WeightedPick(System.Random rng)
    {
        float wsum = 0; foreach (var s in Items) wsum += Mathf.Max(0.0001f, s.Weight);
        float r = (float)(rng.NextDouble() * wsum);
        foreach (var s in Items) { r -= Mathf.Max(0.0001f, s.Weight); if (r <= 0) return s; }
        return Items.Count > 0 ? Items[^1] : null;
    }
}
