﻿// Bag.cs に追加してもよいが、Spin 起点の方が見通しが良い
// SpinSystem.cs
using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(menuName = "Lucklike/SpinSystemEx")]
public class SpinSystemEx : SpinSystem
{
    public SymbolSO[,] SpinDeal(Bag bag, System.Random rng)
    {
        int total = Width * Height;

        // 1) プール作成：バッグの実個数をそのままコピー
        var pool = new List<SymbolSO>(bag.Items);

        // 2) もし持ち札が盤面より多い場合は total 枚だけ無作為抽出
        if (pool.Count > total)
        {
            // フィッシャー–イェーツでシャッフル後に先頭 total を採用
            for (int i = pool.Count - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (pool[i], pool[j]) = (pool[j], pool[i]);
            }
            pool = pool.GetRange(0, total);
        }

        // 3) 空白を“不足分だけ”追加（＝固定個数）
        int empties = Mathf.Max(0, total - pool.Count);
        for (int i = 0; i < empties; i++) pool.Add(null);

        // 4) もう一度シャッフルして盤面へ「配る」（非復元）
        for (int i = pool.Count - 1; i > 0; i--)
        {
            int j = rng.Next(i + 1);
            (pool[i], pool[j]) = (pool[j], pool[i]);
        }

        var grid = new SymbolSO[Width, Height];
        int k = 0;
        for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width; x++)
                grid[x, y] = pool[k++];

        return grid;
    }
}
