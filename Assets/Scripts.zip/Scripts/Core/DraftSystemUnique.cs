// DraftSystem.cs �̒u�������i��薳���Łj
using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Lucklike/DraftSystem (Unique)")]
public class DraftSystemUnique : DraftSystem
{

    public override List<SymbolSO> GenerateSymbolOptions(System.Random rng, int count = 3)
    {
        var pool = symbolCatalog.BuildWeightedPool();
        var options = new List<SymbolSO>(count);
        while (options.Count < count && pool.Count > 0)
        {
            int idx = rng.Next(pool.Count);
            var pick = pool[idx];
            options.Add(pick);
            pool.RemoveAll(p => p == pick); // �� �����S�폜
        }
        return options;
    }

    public override List<RelicSO> GenerateRelicOptions(System.Random rng, int count = 3)
    {
        var pool = relicCatalog.BuildWeightedPool();
        var options = new List<RelicSO>(count);
        while (options.Count < count && pool.Count > 0)
        {
            int idx = rng.Next(pool.Count);
            var pick = pool[idx];
            options.Add(pick);
            pool.RemoveAll(p => p == pick); // �� �����S�폜
        }
        return options;
    }
}
