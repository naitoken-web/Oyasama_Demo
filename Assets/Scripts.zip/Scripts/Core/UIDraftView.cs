// UIDraftView.cs�i�ǉ��E�u���j
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIDraftView : MonoBehaviour
{
    [SerializeField] GameObject root;         // �p�l���̃��[�g
    [SerializeField] RectTransform panel;     // �������Ώ�
    [SerializeField] CanvasGroup cg;          // �����x�Ǘ��i�������AddComponent�ł��j
    [SerializeField] UIDraftCard[] slots;     // 3��
    [SerializeField] Button skipButton;

    [Header("Slide FX")]
    [SerializeField] Vector2 offscreenOffset = new Vector2(0, -600f); // ��ʉ�����
    [SerializeField, Min(0.05f)] float slideDuration = 0.25f;
    [SerializeField] AnimationCurve slideEase = AnimationCurve.EaseInOut(0, 0, 1, 1);

    [SerializeField] Button rerollButton;
    public event System.Action OnRerollRequested; // GameController���n���h��

    Vector2 panelHome;

    void Awake()
    {
        if (panel == null) panel = root.GetComponent<RectTransform>();
        if (cg == null) cg = root.GetComponent<CanvasGroup>() ?? root.AddComponent<CanvasGroup>();
        cg.interactable = true;   // �� �N���b�N���u���b�N���Ȃ�
        cg.blocksRaycasts = true;   // �� �p�l�����̃{�^�����N���b�N��
        root.SetActive(false);
        cg.alpha = 0f;
    }

    void WireReroll(bool interactable)
    {
        if (!rerollButton) return;                  // �� �C���X�y�N�^���ݒ�K�[�h
        rerollButton.gameObject.SetActive(true);    // ��Ɍ�����i��Ԃ� interactable �Ő���j
        rerollButton.onClick.RemoveAllListeners();
        rerollButton.onClick.AddListener(() => OnRerollRequested?.Invoke());
        rerollButton.interactable = interactable;
    }

    IEnumerator SlideIn()
    {
        root.SetActive(true);
        panel.anchoredPosition = panelHome + offscreenOffset;
        cg.alpha = 0f;

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / slideDuration;
            float e = slideEase.Evaluate(Mathf.Clamp01(t));
            panel.anchoredPosition = Vector2.Lerp(panelHome + offscreenOffset, panelHome, e);
            cg.alpha = e;
            yield return null;
        }
        panel.anchoredPosition = panelHome;
        cg.alpha = 1f;
    }

    IEnumerator SlideOut()
    {
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / slideDuration;
            float e = slideEase.Evaluate(Mathf.Clamp01(t));
            panel.anchoredPosition = Vector2.Lerp(panelHome, panelHome + offscreenOffset, e);
            cg.alpha = 1f - e;
            yield return null;
        }
        cg.alpha = 0f;
        root.SetActive(false);
    }

    // --- �╨�h���t�g�F���l�� ---
    public IEnumerator ShowRelicsSlideInEx(
        List<RelicSO> options,
        Action<RelicSO> onPick,
        Action onSkip,
        Action<Action<List<RelicSO>>, Action<bool>> setup
    )
    {
        List<RelicSO> current = new(options);

        void BindCards()
        {
            for (int i = 0; i < slots.Length; i++)
            {
                var r = current[i];
                slots[i].Bind(r.Icon, string.IsNullOrEmpty(r.Id) ? "Relic" : r.Id,
                              r.Description, null);
                slots[i].ApplyRarity(r.Rarity); // �� ���A���e�B�w�i
            }
        }

        void SetOptions(List<RelicSO> newOptions) { current = new(newOptions); BindCards(); }
        void EnableReroll(bool on) { WireReroll(on); }

        WireReroll(false);          // ��Ƀ��X�i�[�����Č����邾��
        setup?.Invoke(SetOptions, EnableReroll);

        BindCards();
        yield return SlideIn();

        bool decided = false;
        for (int i = 0; i < slots.Length; i++)
        {
            int idx = i;
            slots[i].SetOnPick(() => {
                if (decided) return;
                decided = true;
                onPick?.Invoke(current[idx]);
                StartCoroutine(SlideOut());
            });
        }
        skipButton.onClick.RemoveAllListeners();
        skipButton.onClick.AddListener(() => {
            if (decided) return;
            decided = true;
            onSkip?.Invoke();
            StartCoroutine(SlideOut());
        });

        while (!decided) yield return null;
        yield return new WaitForSeconds(slideDuration);
    }

    // UIDraftView.cs�i�V�K�FShowSymbolsSlideInEx�j
    // UIDraftView.cs�i�����ւ��j
    public IEnumerator ShowSymbolsSlideInEx(
        List<SymbolSO> options,
        Action<SymbolSO> onPick,
        Action onSkip,
        Action<Action<List<SymbolSO>>, Action<bool>> setup
    )
    {
        List<SymbolSO> current = new(options);

        void BindCards()
        {
            for (int i = 0; i < slots.Length; i++)
            {
                var s = current[i];
                slots[i].Bind(s.Icon, string.IsNullOrEmpty(s.Id) ? "Symbol" : s.Id,
                              s.Description, null);
                slots[i].ApplyRarity(s.Rarity); // �� ���A���e�B�w�i
            }
        }

        void SetOptions(List<SymbolSO> newOptions) { current = new(newOptions); BindCards(); }
        void EnableReroll(bool on) { WireReroll(on); }   // �� ��ԕύX�͂��������ōs��

        // �� ��Ɂg�����ڂ̏������h�����i���X�i�[�z�����\���j�B������ disable ���Ȃ�
        WireReroll(false);          // Listeners�𒣂違�\���͂���iinteractable����false�j
                                    // �� �Ăяo�����Ƀt�b�N��n�� �� �����ŏ������ɉ����� enableReroll(true/false) ���Ă�ł��炤
        setup?.Invoke(SetOptions, EnableReroll);

        BindCards();
        yield return SlideIn();

        bool decided = false;
        for (int i = 0; i < slots.Length; i++)
        {
            int idx = i;
            slots[i].SetOnPick(() => {
                if (decided) return;
                decided = true;
                onPick?.Invoke(current[idx]); // �� current ����m��
                StartCoroutine(SlideOut());
            });
        }
        skipButton.onClick.RemoveAllListeners();
        skipButton.onClick.AddListener(() => {
            if (decided) return;
            decided = true;
            onSkip?.Invoke();
            StartCoroutine(SlideOut());
        });

        while (!decided) yield return null;
        yield return new WaitForSeconds(slideDuration);
    }


    // Reroll�{�^�������؂�ւ��������̃w���p
    public void SetRerollInteractable(bool on)
    {
        if (rerollButton) rerollButton.interactable = on;
    }


}
