﻿// SpinAnimator.cs（列別→全体一括 抽選＆描画 版）
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpinAnimator : MonoBehaviour
{
    [SerializeField] BoardView boardView;

    [Header("Timing")]
    [SerializeField, Min(0f)] float columnStagger = 0.08f; // 列が“参加”し始める遅延（見た目の段階的スタート）
    [SerializeField, Min(0.1f)] float baseDuration = 0.9f;  // 全体のスピン時間
    [SerializeField] AnimationCurve ease = AnimationCurve.EaseInOut(0, 0, 1, 1);
    [SerializeField, Tooltip("最速〜最遅の更新間隔")] Vector2 tickIntervalRange = new Vector2(0.02f, 0.09f);

    Bag currentBag;
    public void SetBag(Bag bag) => currentBag = bag;

    SymbolView GetView(int x, int y) => boardView != null ? boardView.GetCellView(x, y) : null;

    // 内部状態
    SymbolSO[,] currentFxGrid;                // 現在“表示中”の盤面（出現上限チェック用）
    Dictionary<SymbolSO, int> bagCounts;      // 所持シンボルの枚数辞書
    int totalEmpty;                           // 空白総枠 = 総セル数 - 所持総枚数

    Dictionary<SymbolSO, int> BuildBagCounts()
    {
        var d = new Dictionary<SymbolSO, int>();
        if (currentBag?.Items != null)
        {
            foreach (var s in currentBag.Items)
            {
                if (s == null) continue;
                d.TryGetValue(s, out int c);
                d[s] = c + 1;
            }
        }
        return d;
    }

    // ある集合（除外集合）を除いた“現在表示中”の使用数を数える
    void CountCurrentExcluding(HashSet<(int x, int y)> exclude, out Dictionary<SymbolSO, int> used, out int emptyUsed, int W, int H)
    {
        used = new Dictionary<SymbolSO, int>();
        emptyUsed = 0;
        for (int y = 0; y < H; y++)
        {
            for (int x = 0; x < W; x++)
            {
                if (exclude != null && exclude.Contains((x, y))) continue;
                var s = currentFxGrid[x, y];
                if (s == null) emptyUsed++;
                else
                {
                    used.TryGetValue(s, out int c);
                    used[s] = c + 1;
                }
            }
        }
    }

    // 残り枚数（bagCounts - used）から、更新対象セル数 N 分を「非復元で」サンプル
    List<SymbolSO> SampleWithoutReplacement(System.Random rng, Dictionary<SymbolSO, int> remainder, int emptyRemain, int N)
    {
        var pool = new List<SymbolSO>(N * 2);
        foreach (var kv in remainder) for (int i = 0; i < kv.Value; i++) pool.Add(kv.Key);
        for (int i = 0; i < emptyRemain; i++) pool.Add(null);

        if (pool.Count == 0) { for (int i = 0; i < N; i++) pool.Add(null); }

        // シャッフル
        for (int i = pool.Count - 1; i > 0; i--)
        {
            int j = rng.Next(i + 1);
            (pool[i], pool[j]) = (pool[j], pool[i]);
        }

        // 先頭から N 件（不足すれば空白で埋め）
        var outList = new List<SymbolSO>(N);
        for (int i = 0; i < N; i++) outList.Add(i < pool.Count ? pool[i] : null);
        return outList;
    }

    public IEnumerator PlaySpinTo(SymbolSO[,] target, System.Random rng)
    {
        int W = target.GetLength(0);
        int H = target.GetLength(1);
        if (GetView(0, 0) == null) { Debug.LogWarning("[SpinAnimator] BoardView cell is null. Skip FX."); yield break; }

        // 初期化：全セル空表示＆内部盤面クリア
        currentFxGrid = new SymbolSO[W, H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
            {
                var v = GetView(x, y);
                if (v != null) { v.Clear(); }
                currentFxGrid[x, y] = null;
            }

        bagCounts = BuildBagCounts();
        int bagTotal = 0; foreach (var c in bagCounts.Values) bagTotal += c;
        totalEmpty = Mathf.Max(0, W * H - bagTotal);

        float t = 0f;
        float tickAcc = 0f;

        // 各列の“参加開始時間”を事前計算（見た目の段階的スタート）
        var colStart = new float[W];
        for (int x = 0; x < W; x++) colStart[x] = columnStagger * x;

        while (t < 1f)
        {
            t = Mathf.Min(1f, t + Time.deltaTime / Mathf.Max(0.0001f, baseDuration));
            float interval = Mathf.Lerp(tickIntervalRange.x, tickIntervalRange.y, ease.Evaluate(t));
            tickAcc += Time.deltaTime;

            if (tickAcc >= interval)
            {
                tickAcc = 0f;

                // いま“回す対象”になるセル集合（アクティブ列のみ）を作る
                var activeCells = new List<(int x, int y)>(W * H);
                for (int x = 0; x < W; x++)
                {
                    if (t * baseDuration >= colStart[x])
                    {
                        for (int y = 0; y < H; y++) activeCells.Add((x, y));
                    }
                }
                if (activeCells.Count == 0) { yield return null; continue; }

                // 更新順をランダム化（毎ティックごとにグリッド全体でバラける）
                for (int i = activeCells.Count - 1; i > 0; i--)
                {
                    int j = rng.Next(i + 1);
                    (activeCells[i], activeCells[j]) = (activeCells[j], activeCells[i]);
                }

                // まとめて“非復元”サンプル：
                //   1) 今回更新するセル集合を exclude として、他のセルで使用中の数を集計
                var exclude = new HashSet<(int x, int y)>(activeCells);
                CountCurrentExcluding(exclude, out var usedOthers, out int emptyUsedOthers, W, H);

                //   2) 残り枚数 = bagCounts - usedOthers
                var remainder = new Dictionary<SymbolSO, int>();
                foreach (var kv in bagCounts)
                {
                    int u = usedOthers.TryGetValue(kv.Key, out var c) ? c : 0;
                    int rem = kv.Value - u;
                    if (rem > 0) remainder[kv.Key] = rem;
                }
                int emptyRemain = Mathf.Max(0, totalEmpty - emptyUsedOthers);

                //   3) アクティブセル数 分を一括サンプル（非復元）
                var draws = SampleWithoutReplacement(rng, remainder, emptyRemain, activeCells.Count);

                //   4) 反映：draws[i] を activeCells[i] に貼り、currentFxGrid も更新
                for (int i = 0; i < activeCells.Count; i++)
                {
                    var (x, y) = activeCells[i];
                    var v = GetView(x, y);
                    var s = draws[i];
                    currentFxGrid[x, y] = s;
                    if (v != null)
                    {
                        if (s == null) v.Clear(); else v.Bind(s.Icon, "");
                    }
                }
            }
            yield return null;
        }

        // 停止：最終ターゲットを確定描画
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
            {
                var v = GetView(x, y);
                if (v == null) continue;
                var s = target[x, y];
                if (s == null) v.Clear(); else v.Bind(s.Icon, "");
            }
        yield return new WaitForSeconds(0.3f);
    }
}
